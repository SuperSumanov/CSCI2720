const express = require('express');
const session = require('express-session');
const db = require('./config/db');

const authRoutes = require('./routes/auth');
const adminEventRoutes = require('./routes/adminEvents');
const adminUserRoutes = require('./routes/adminUsers');

const { fetchAndStoreData } = require('./services/saveData');

const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(session({
  secret: 'CSCI2720',
  resave: false,
  saveUninitialized: false
}));

// Load user from session
app.use((req, res, next) => {
  if (req.session.user) req.user = req.session.user;
  next();
});

// Routes
app.use('/login', authRoutes);
app.use('/logout', authRoutes);
app.use('/admin/events', adminEventRoutes);
app.use('/admin/users', adminUserRoutes);

// Default route
app.use((req, res) => {
  res.send('Hello World!');
});

// Fetch XML data on startup
fetchAndStoreData();

module.exports = app;
